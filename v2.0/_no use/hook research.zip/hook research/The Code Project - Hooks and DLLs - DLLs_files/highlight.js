/*
Text marker code 
Ashok Hariharan
http://www.unganisha.org/home/pages/dhtmlmarker/

Butchered by Chris Maunder to allow multiple word match
and preservation of search word case. http://www.codeproject.com
*/


/*helper function , gets innerHtml of a layer */
/*code ripped from ppk : http://xs4all.nsl/~ppk/js/ */
function getLayerHtml(id)
{
	var inHtml = new String('');
	if (document.getElementById)
	{
		x = document.getElementById(id);
		inHtml = x.innerHTML;
	}
	else
	 if (document.all)
	{
		x = document.all[id];
		inHtml = x.innerHTML;
	}
	return inHtml;
}

/*helper function , sets the innerHtml of a layer */
/*code ripped from ppk : http://xs4all.nsl/~ppk/js/ */
function setLayerHtml(text,id)
{
	if (document.getElementById)
	{
		elemObj = document.getElementById(id);
		elemObj.innerHTML = text;
	}
	else if (document.all)
	{
		elemObj = document.all[id];
		elemObj.innerHTML = text;
	}
	/*
	this is ns4 compatible code ...
	*/
	/*
	else if (document.layers)
	{
		x = document.layers[id];
		text2 = '<P CLASS="testclass">' + text + '</P>;';
		x.document.open();
		x.document.write(text2);
		x.document.close();
	}
	*/
}

// Simple word replace
function replaceMe(str, phrase, chg) 
{
	var pattern = new RegExp (phrase ,'ig');
	return str.replace( pattern, chg);
}


// Wrap a word in a phrase with two strings.
// Input string contains 'phrase', is plain text and has no HTML tags.
// Output will be the string with 'phrase' wrapped by prefix and suffix strings.
function WrapMe(str, phrase, prefix, suffix) 
{
	var nPos;
	var result = "";
	var start  = 0;
	var Searchable = str.toLowerCase();
	var Length = phrase.length;
	
	phrase = phrase.toLowerCase();

	while ( (nPos = Searchable.indexOf(phrase, start)) >= 0 )
	{
		result += str.substr(start, nPos-start);
		result += prefix + str.substr(nPos, Length) + suffix;
		start = nPos + Length;
	}
	result += str.substr(start);
	
	return result;
}

// Adds markup to text by sequentially searching for blocks of non-marked up text 
// that contains the search phrase
function markText(txtKeyword, inputHtml) 
{
	var prefix = '<span  style="background-color:yellow;color:red;font-weight:bold;">';
	var suffix = '</span>';
	var re	   = new RegExp("(\<[^>][^<]*\>)([^<]*)","g");	// create non-greedy regex match

	/*
	note : 
	in 99% of cases <[^>]*\>)([^<]*) 
	should also work , i did have the rare case where some invisible 
	characters caused this to crap out ....
	*/
	
	var varMatches;											// matches array 
	var outHtml = new String('');							// init html string 
	while ((varMatches = re.exec(inputHtml)) != null)		// exec sequentially to apply span tags
	{
		outHtml += varMatches[1]; 							// html tag part
		outHtml += WrapMe(varMatches[2], txtKeyword, prefix, suffix); 
	}
	return outHtml;

}

// Highlights a bunch of words.
function Highlight(Keywords)
{
	var inHtml = '<em></em>'+getLayerHtml('contentdiv');
	for (var i=0; i<Keywords.length; i++)
		inHtml = markText(Keywords[i], inHtml);
	setLayerHtml(inHtml,'contentdiv');
}


