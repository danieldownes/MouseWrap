#ifdef _MSC_VER
#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#endif

#include "MSNHook.h"

HINSTANCE g_hThisDll;
BOOL checkProcess;

int APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	switch(dwReason)
	{
	case DLL_PROCESS_ATTACH:
		checkProcess = true;
		g_hThisDll = hInstance;
		break;
	case DLL_PROCESS_DETACH:
		{
			if(pfnWndProc)
			{
				if(IsWindowUnicode(g_hwndToMineWindow))
				{
					SetWindowLongW(g_hwndToMineWindow, GWL_WNDPROC, 
						(LPARAM)(WNDPROC)pfnWndProc);
				}
				else
				{
					SetWindowLongA(g_hwndToMineWindow, GWL_WNDPROC, 
						(LPARAM)(WNDPROC)pfnWndProc);
				}
			}
		}
	}

return TRUE;
}


// Sets up a hook to detect when MSN starts
void APIENTRY ShellDll_Hook()
{
	g_hShellHook = SetWindowsHookEx(WH_CBT, ShellDll_MainHook, g_hThisDll, 0);
}


void APIENTRY ShellDll_Unhook()
{
	if(g_hShellHook != NULL)
		UnhookWindowsHookEx(g_hShellHook);
}


LRESULT CALLBACK ShellDll_MainHook(int nCode, WPARAM wParam, LPARAM lParam)
{
	TCHAR szClass[MAX_PATH] = {0};

	BOOL doneonce = false;

	if(nCode < 0)
		return CallNextHookEx(g_hShellHook, nCode, wParam, lParam);
	
	// Call filter everytime a new window is created
	if(nCode == HCBT_CREATEWND)
	{
		// Get the HWND of the window
		HWND hwndToNewWindow = reinterpret_cast<HWND>(wParam);

		GetClassName(hwndToNewWindow, szClass, MAX_PATH);

		// Compare class name with MSN's class name
		if(!lstrcmpi(szClass, __TEXT("MSBLClass")))
		{
			// Unhook hook when MSN Class found to save resources
			ShellDll_Unhook();
			g_hwndToMineWindow = hwndToNewWindow;


			// Check and see if window is unicode or ascii
			if(IsWindowUnicode(g_hwndToMineWindow))
			{
				// Set new window procedure to MSN's class
				pfnWndProc = (WNDPROC)SetWindowLongW(g_hwndToMineWindow, GWL_WNDPROC, 
				(LPARAM)(WNDPROC)MSN_SubClassWndProc);
			}
			else
			{
				// Set new window procedure to MSN's class
				pfnWndProc = (WNDPROC)SetWindowLongA(g_hwndToMineWindow, GWL_WNDPROC, 
					(LPARAM)(WNDPROC)MSN_SubClassWndProc);
			}
		}
	}

	return CallNextHookEx(NULL, nCode, wParam, lParam);
}

//MSN Subclass wndproc
LRESULT WINAPI MSN_SubClassWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LRESULT lResult = 0;

	HMENU m_hMenu = GetMenu(hwnd);
	HMENU m_hSysMenu;
	
	switch(uMsg)
	{

	case WM_SHOWWINDOW:
		if(checkProcess)
		{
			SetWindowText(hwnd, "MSN Messenger Service Extensions");
			AppendMenu(m_hMenu, MF_BYPOSITION | MF_STRING | MF_ENABLED, 190, "MSN Extended");


			m_hSysMenu = GetSystemMenu(hwnd, FALSE);
			AppendMenu(m_hSysMenu, MF_SEPARATOR, 130, "-");

			/* The below menu item has the identifier 112 because System menu requires
			   identifiers that are multiples of 16... thus this new item being the 7th
			   item, it would have an identifier of 16 X 7, which is 112 */

			AppendMenu(m_hSysMenu, MF_STRING, 112, "&About Extensions");

			checkProcess = false;
		}
		break;

	case WM_GETMINMAXINFO:
		checkProcess =true;
		break;

	default:
		break;
	}

	// Call previous window procedure
	if(IsWindowUnicode(hwnd))
	{
		lResult = CallWindowProcW((WNDPROC) (DWORD)pfnWndProc, hwnd, uMsg, wParam, lParam);
	}
	else
	{
		lResult = CallWindowProcA((WNDPROC) (DWORD)pfnWndProc, hwnd, uMsg, wParam, lParam);
	}

	return lResult;
}