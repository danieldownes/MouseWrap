Title: A way to subclass MSN Messenger, add hooks, dynamically modify menus and control its behavior
Description: This program will teach you how to create hooks and dynamically control the behavior, outlook or anything related to a window. This program shows subclassing for MSN Messenger, by setting up a hook and then dynamically adding Menu items to MSN Messenger and handling its behaviour to certain events. With this technique, you can virtually do anything to any window or application of which you do not have access to code. Subclassing and hooking can be VERY powerful when used properly. Please check it out and please vote (o= Thanks
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=3087&lngWId=3

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
