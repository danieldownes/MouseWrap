
// Prevent multiple inclusions
#define WIN32_LEAN_AND_MEAN
#define STRICT

#ifndef _APP_DEFS_
#define _APP_DEFS_

#include <windows.h>
#include <windowsx.h>

#endif	// _APP_DEFS_