#ifdef _MSC_VER

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "MSNHook.lib")

#endif

#include "MSNExe.h"
#include "MSNHook.h"
#include <commctrl.h>
#include <shellapi.h>
#include "resource.h" 

const int WM_MYMESSAGE = WM_APP + 1;

HICON g_hIconLarge;
HICON g_hIconSmall;
HINSTANCE g_hInstance;

void OnInitDialog(HWND);
void OnOK(HWND);

BOOL TrayIcon(HWND, DWORD);
void ContextMenu(HWND);

BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);


int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevious, LPTSTR lpsz, int iCmd)
{

	g_hInstance = hInstance;
	g_hIconSmall = static_cast<HICON>(LoadImage(hInstance, MAKEINTRESOURCE(IDI_ICON), IMAGE_ICON,
		GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CXSMICON), 0));

	// Create an invisible dialog to get messages from the icon
	HWND hDlg = CreateDialog(hInstance, "DLG_MAIN", NULL, APP_DlgProc);

	// Show the icon
	TrayIcon(hDlg, NIM_ADD);

	// Install the MSN's hook
	ShellDll_Hook();

	MSG msg;
	while(GetMessage(&msg, NULL, 0, 0))
	{
		if(!IsDialogMessage(hDlg, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	// Uninstall the hook
	ShellDll_Unhook();

	// Remove the icon
	TrayIcon(hDlg, NIM_DELETE);

	DestroyWindow(hDlg);
	DestroyIcon(g_hIconSmall);
	
	return 1;
}


BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uiMsg)
	{
	case WM_COMMAND:
		switch(wParam)
		{
		case IDCANCEL:
			PostQuitMessage(0);
			return FALSE;
		}
		break;

		case WM_MYMESSAGE:
			if(wParam == IDI_ICON)
			{
				switch(lParam)
				{
				case WM_RBUTTONUP:
					ContextMenu(hDlg);
					break;
				}
			}
			break;
	}

	return FALSE;
}

void OnOK(HWND hDlg)
{
	return;
}

void OnInitDialog(HWND hDlg)
{
	SendMessage(hDlg, WM_SETICON, FALSE, reinterpret_cast<LPARAM>(g_hIconSmall));
}

// Shows an icon in the tray area
BOOL TrayIcon(HWND hWnd, DWORD msg)
{
	NOTIFYICONDATA nid;
	ZeroMemory(&nid, sizeof(NOTIFYICONDATA));
	nid.cbSize = sizeof(NOTIFYICONDATA);
	nid.hWnd = hWnd;
	nid.uID = IDI_ICON;
	nid.uFlags = NIF_TIP | NIF_ICON | NIF_MESSAGE;
	nid.uCallbackMessage = WM_MYMESSAGE;
	nid.hIcon = g_hIconSmall;
	lstrcpyn(nid.szTip, __TEXT("Sweep the Minesweeper"), 22);
	
	return Shell_NotifyIcon(msg, &nid);
}

// Shows up the context menu for the icon
void ContextMenu(HWND hwnd)
{
	POINT pt;
	GetCursorPos(&pt);

	HMENU hmenu = LoadMenu(g_hInstance, MAKEINTRESOURCE(IDR_MENU));
	HMENU hmnuPopup = GetSubMenu(hmenu, 0);
	SetMenuDefaultItem(hmnuPopup, IDOK, FALSE);
	SetForegroundWindow(hwnd);
	TrackPopupMenu(hmnuPopup, TPM_LEFTALIGN, pt.x, pt.y, 0, hwnd, NULL);
	SetForegroundWindow(hwnd);
	DestroyMenu(hmnuPopup);
	DestroyMenu(hmenu);
}