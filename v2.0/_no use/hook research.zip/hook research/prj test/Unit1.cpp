//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

HINSTANCE hInst;


//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

// Forward declaration
static LRESULT CALLBACK msghook(int nCode, WPARAM wParam, LPARAM lParam);

bool bMoving = false;

UINT UWM_MOUSEHOOK;
HHOOK hook;


//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
    //if(bMoving)
//        Application->Messagebox(

    lbl->Caption = "Moving";


    bMoving = false;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------


/****************************************************************
*                              msghook
* Inputs:
*       int nCode: Code value
*       WPARAM wParam: parameter
*       LPARAM lParam: parameter
* Result: LRESULT
*
* Effect:
*       If the message is a mouse-move message, posts it back to
*       the server window with the mouse coordinates
* Notes:
*       This must be a CALLBACK function or it will not work!
****************************************************************/

static LRESULT CALLBACK msghook(int nCode, WPARAM wParam, LPARAM lParam)
   {
    // If the value of nCode is < 0, just pass it on and return 0
    // this is required by the specification of hook handlers
    if(nCode < 0)
      { /* pass it on */
       CallNextHookEx(hook, nCode,
                   wParam, lParam);
       return 0;
      } /* pass it on */

    // Read the documentation to discover what WPARAM and LPARAM
    // mean. For a WH_MESSAGE hook, LPARAM is specified as being
    // a pointer to a MSG structure, so the code below makes that
    // structure available

    LPMSG msg = (LPMSG)lParam;

    // If it is a mouse-move message, either in the client area or
    // the non-client area, we want to notify the parent that it has
    // occurred. Note the use of PostMessage instead of SendMessage
    if(msg->message == WM_MOUSEMOVE ||
       msg->message == WM_NCMOUSEMOVE)
     // PostMessage(hWndServer,
     //             UWM_MOUSEMOVE,
     //             0, 0);
         bMoving = true;

    // Pass the message on to the next hook
    return CallNextHookEx(hook, nCode,
                       wParam, lParam);
   } // msghook








//---------------------------------------------------------------------------
/*

	ShowWindow( hWnd, nCmdShow );
	UpdateWindow( hWnd );
	while( GetMessage( &msg, NULL, 0, 0) )
	{
		// If we are filtering then call the message filter.
		//..................................................
		if ( bHooked && bFilterIt )
			CallMsgFilter( &msg, WM_USER );
			
		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}
	UnhookWindowsHookEx( hHook );
	return( msg.wParam );
}


LRESULT CALLBACK HookProcedure( int nCode, WPARAM wParam, LPARAM lParam )
{
	// If this is not our code then pass it on to the next
	// filter proc (if any).
	//.....................................................
	if ( nCode != WM_USER )
		CallNextHookEx( hHook, nCode, wParam, lParam );
	else
	{
		LPMSG msg = (LPMSG)lParam;
		if ( msg->message == WM_PAINT )
		{
			MessageBeep(0);
			return( TRUE );
		}
	}	
	return( FALSE );
}


LRESULT CALLBACK WndProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	switch( uMsg )
	{
		case WM_COMMAND :
			switch( LOWORD( wParam ) )
			{
				case IDM_TEST :
					if ( bFilterIt )
					{
						bFilterIt = FALSE;
						MessageBox( hWnd, "Filtering is OFF", lpszAppName,
						MB_OK );
					}
					else
					{
						bFilterIt = TRUE;
						MessageBox( hWnd, "Filtering is ON", lpszAppName,
						MB_OK );
					}

					break;
			}
	}
}

*/

void __fastcall TForm1::FormCreate(TObject *Sender)
{

         // Save the instance handle because we need it to set the hook later
//         hInstance = hInst;
         // This code initializes the hook notification message
        // UWM_MOUSEHOOK = RegisterWindowMessage(UWM_MOUSEHOOK_MSG);


         hook = SetWindowsHookEx(
                           WH_GETMESSAGE,
                           (HOOKPROC)msghook,
                           Form1->Handle ,
                           0);
    //     if(hook != NULL)
    //     { /* success */
    //      return TRUE;
    //     } /* fail */
    //   return FALSE;


    
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormDestroy(TObject *Sender)
{
       BOOL unhooked = UnhookWindowsHookEx(hook);
//    if(unhooked)
//       hWndServer = NULL;
}
//---------------------------------------------------------------------------

